class Event < ActiveRecord::Base
end
